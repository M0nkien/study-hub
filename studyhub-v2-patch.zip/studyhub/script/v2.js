/* =========================================================
   STUDY HUB V2 — UI helpers
   Keeps the original project logic untouched.
   ========================================================= */

(function () {
    "use strict";

    function normalizedPath() {
        return window.location.pathname.replace(/\\/g, "/").replace(/\/$/, "");
    }

    function markActiveNavigation() {
        const path = normalizedPath();
        const current = path.split("/").pop() || "index.html";
        const isSubjectDetail = path.includes("/subjects/") && current !== "subjects.html";

        document.querySelectorAll(".nav a").forEach(function (link) {
            const href = (link.getAttribute("href") || "").split("#")[0];
            const target = href.split("/").pop();
            let active = false;

            if (isSubjectDetail && target === "subjects.html") active = true;
            else if (target && target === current) active = true;
            else if ((current === "" || current === "index.html") && target === "index.html") active = true;

            link.classList.toggle("v2-active", active);
            if (active) link.setAttribute("aria-current", "page");
            else link.removeAttribute("aria-current");
        });
    }

    function initScrollTop() {
        const button = document.createElement("button");
        button.className = "v2-scroll-top";
        button.type = "button";
        button.setAttribute("aria-label", "Späť hore");
        button.textContent = "↑";
        document.body.appendChild(button);

        function sync() {
            button.classList.toggle("visible", window.scrollY > 520);
        }

        window.addEventListener("scroll", sync, { passive: true });
        button.addEventListener("click", function () {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
        sync();
    }

    function initReveal() {
        if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
        const candidates = document.querySelectorAll(
            ".v2-quick-card, .v2-continue-card, .v2-update-card, .subject-card, .content-block, .roadmap-lane"
        );
        if (!candidates.length || !("IntersectionObserver" in window)) return;

        candidates.forEach(function (el) { el.classList.add("v2-reveal"); });
        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) return;
                entry.target.classList.add("v2-visible");
                observer.unobserve(entry.target);
            });
        }, { threshold: 0.08, rootMargin: "0px 0px -24px 0px" });

        candidates.forEach(function (el) { observer.observe(el); });
    }

    function initSubjectSectionSpy() {
        const sidebar = document.querySelector(".subject-sidebar");
        if (!sidebar || !("IntersectionObserver" in window)) return;

        const links = Array.from(sidebar.querySelectorAll('a[href^="#"]'));
        const sections = links
            .map(function (link) {
                const id = link.getAttribute("href").slice(1);
                const section = document.getElementById(id);
                return section ? { link: link, section: section } : null;
            })
            .filter(Boolean);
        if (!sections.length) return;

        const observer = new IntersectionObserver(function (entries) {
            const visible = entries
                .filter(function (entry) { return entry.isIntersecting; })
                .sort(function (a, b) { return b.intersectionRatio - a.intersectionRatio; });
            if (!visible.length) return;

            const id = visible[0].target.id;
            sections.forEach(function (item) {
                item.link.classList.toggle("v2-section-active", item.section.id === id);
            });
        }, { rootMargin: "-22% 0px -62% 0px", threshold: [0, .08, .2, .5] });

        sections.forEach(function (item) { observer.observe(item.section); });
    }

    function parseJSON(key, fallback) {
        try {
            const raw = localStorage.getItem(key);
            return raw ? JSON.parse(raw) : fallback;
        } catch (error) {
            return fallback;
        }
    }

    function updateHomeSnapshot() {
        const root = document.getElementById("v2HomeSnapshot");
        if (!root) return;

        const learned = parseJSON("studyHubProgress", parseJSON("mikStudyLearned", {}));
        const results = parseJSON("studyHubQuizResults", []);
        const last = parseJSON("studyHubLastLocation", null);

        const done = Object.values(learned || {}).filter(Boolean).length;
        const best = Array.isArray(results) && results.length
            ? Math.max.apply(null, results.map(function (item) { return Number(item.percent) || 0; }))
            : 0;

        const doneEl = document.getElementById("v2DoneSections");
        const bestEl = document.getElementById("v2BestQuiz");
        const lastEl = document.getElementById("v2LastOpen");
        const continueLink = document.getElementById("v2ContinueLink");

        if (doneEl) doneEl.textContent = String(done);
        if (bestEl) bestEl.textContent = best + "%";
        if (lastEl) lastEl.textContent = last && last.label ? last.label : "Zatiaľ nič otvorené";
        if (continueLink && last && last.href) continueLink.href = last.href;
    }

    function improveMobileMenu() {
        const nav = document.querySelector(".nav");
        const toggle = document.querySelector(".menu-toggle");
        if (!nav || !toggle) return;

        toggle.setAttribute("aria-expanded", nav.classList.contains("open") ? "true" : "false");
        toggle.setAttribute("aria-label", "Otvoriť navigáciu");

        toggle.addEventListener("click", function () {
            window.setTimeout(function () {
                toggle.setAttribute("aria-expanded", nav.classList.contains("open") ? "true" : "false");
            }, 0);
        });

        document.addEventListener("click", function (event) {
            if (!nav.classList.contains("open")) return;
            if (nav.contains(event.target) || toggle.contains(event.target)) return;
            nav.classList.remove("open");
            toggle.setAttribute("aria-expanded", "false");
        });
    }

    function updateVersionLabels() {
        document.querySelectorAll(".footer-info-card p").forEach(function (el) {
            if (/Study Hub v\d/i.test(el.textContent)) {
                el.textContent = "Study Hub V2 • Aktualizácia: 09/2026";
            }
        });
    }

    document.addEventListener("DOMContentLoaded", function () {
        markActiveNavigation();
        initScrollTop();
        initSubjectSectionSpy();
        updateHomeSnapshot();
        improveMobileMenu();
        updateVersionLabels();
        window.requestAnimationFrame(initReveal);
    });
})();
