// Hlavné funkcie: vyhľadávanie na indexe, mobilné menu, progres na kartách

const SUBJECT_TOTALS = {
    linux: 4,
    msd: 4,
    ccna: 6,
    vvs: 5,
    mat: 5,
    java: 5,
    fyzika: 8
};

function getLearned() {
    const saved = localStorage.getItem("studyHubProgress") || localStorage.getItem("mikStudyLearned");
    if (!saved) return {};
    try { return JSON.parse(saved); } catch { return {}; }
}

function getSubjectProgress(subjectId) {
    const learned = getLearned();
    const count = Object.keys(learned).filter(key => key.startsWith(subjectId + ":") && learned[key]).length;
    const total = SUBJECT_TOTALS[subjectId] || 1;
    return Math.min(100, Math.round((count / total) * 100));
}

function updateIndexProgress() {
    document.querySelectorAll("[data-subject-id]").forEach(card => {
        const subjectId = card.dataset.subjectId;
        const progress = getSubjectProgress(subjectId);
        const text = card.querySelector(".js-progress-text");
        const fill = card.querySelector(".js-progress-fill");

        if (text) text.textContent = progress + "%";
        if (fill) fill.style.width = progress + "%";
    });
}

function initIndexSearch() {
    const searchInput = document.getElementById("searchInput");
    const subjectCards = document.querySelectorAll(".subject-card");

    if (!searchInput) return;

    searchInput.addEventListener("input", function () {
        const searchText = searchInput.value.toLowerCase().trim();

        subjectCards.forEach(function (card) {
            const text = (card.dataset.search || "").toLowerCase();
            card.style.display = text.includes(searchText) ? "block" : "none";
        });
    });
}

function initMobileMenu() {
    const toggle = document.querySelector(".menu-toggle");
    const nav = document.querySelector(".nav");

    if (!toggle || !nav) return;

    toggle.addEventListener("click", function () {
        nav.classList.toggle("open");
    });

    nav.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", () => nav.classList.remove("open"));
    });
}

document.addEventListener("DOMContentLoaded", function () {
    initMobileMenu();
    initIndexSearch();
    updateIndexProgress();
});



/* =========================================================
   Study Hub – stav predmetov + pokračovať v učení
   ========================================================= */

const STUDY_HUB_SUBJECT_STATUS = {
    linux: {
        label: "hotové",
        className: "status-done",
        updated: "Linux kvíz a štúdium príkazov sú pripravené"
    },
    msd: {
        label: "dopĺňa sa",
        className: "status-updating",
        updated: "Rozšírené zadania Z1–Z10 a typické výpočty"
    },
    ccna: {
        label: "dopĺňa sa",
        className: "status-updating",
        updated: "Pridané Packet Tracer príkazy"
    },
    vvs: {
        label: "rozpracované",
        className: "status-progress",
        updated: "Pripravujú sa kódy, obhajoba a projekt robot"
    },
    mat: {
        label: "rozpracované",
        className: "status-progress",
        updated: "Pripravujú sa DR, rady, Laplace a vzorce"
    },
    java: {
        label: "rozpracované",
        className: "status-progress",
        updated: "Pripravuje sa OOP, UML a semestrálna práca"
    },
    fyzika: {
        label: "dopĺňa sa",
        className: "status-updating",
        updated: "Pridaná teória, vzorce, príklady a laboratórium"
    }
};

function addSubjectStatusBadges() {
    document.querySelectorAll(".subject-card[data-subject-id]").forEach(card => {
        const subjectId = card.dataset.subjectId;
        const status = STUDY_HUB_SUBJECT_STATUS[subjectId];

        if (!status || card.querySelector(".subject-status")) {
            return;
        }

        const statusEl = document.createElement("div");
        statusEl.className = "subject-status " + status.className;
        statusEl.innerHTML = `
            <span>${status.label}</span>
            <small>${status.updated}</small>
        `;

        const cardTop = card.querySelector(".card-top");
        if (cardTop) {
            cardTop.insertAdjacentElement("afterend", statusEl);
        }
    });
}

function normalizeStudyHubHref() {
    const path = window.location.pathname.replace(/\\/g, "/");
    const hash = window.location.hash || "";

    const subjectMatch = path.match(/subjects\/([^\/]+\.html)$/);
    if (subjectMatch) {
        return "subjects/" + subjectMatch[1] + hash;
    }

    if (path.endsWith("subjects.html")) {
        return "subjects.html";
    }

    if (path.endsWith("support.html")) {
        return "support.html";
    }

    if (path.endsWith("roadmap.html")) {
        return "roadmap.html";
    }

    return "";
}

function saveLastStudyLocation(label) {
    const href = normalizeStudyHubHref();

    if (!href || href === "index.html") {
        return;
    }

    localStorage.setItem("studyHubLastLocation", JSON.stringify({
        href: href,
        label: label || document.title || "Study Hub",
        savedAt: new Date().toISOString()
    }));
}

function initLastLocationTracking() {
    if (document.body.classList.contains("tracking-disabled")) {
        return;
    }

    const href = normalizeStudyHubHref();

    if (href && href.includes("subjects/")) {
        saveLastStudyLocation(document.title.replace("| Study Hub", "").trim());
    }

    window.addEventListener("hashchange", function () {
        if (normalizeStudyHubHref().includes("subjects/")) {
            const activeSection = document.querySelector(window.location.hash);
            const title = activeSection ? activeSection.querySelector("h2")?.textContent : document.title;
            saveLastStudyLocation(title || document.title);
        }
    });

    document.querySelectorAll(".subject-sidebar a").forEach(link => {
        link.addEventListener("click", function () {
            setTimeout(function () {
                const text = link.textContent.trim();
                saveLastStudyLocation(text);
            }, 100);
        });
    });
}

function initContinueButton() {
    const btn = document.getElementById("continueLearningBtn");
    const label = document.getElementById("continueLearningLabel");

    if (!btn) {
        return;
    }

    const savedRaw = localStorage.getItem("studyHubLastLocation");

    if (!savedRaw) {
        btn.href = "subjects.html";
        if (label) {
            label.textContent = "Zatiaľ nemáš uložené miesto. Začni výberom predmetu.";
        }
        return;
    }

    try {
        const saved = JSON.parse(savedRaw);
        btn.href = saved.href || "subjects.html";

        if (label) {
            label.textContent = "Naposledy: " + (saved.label || saved.href);
        }
    } catch (error) {
        btn.href = "subjects.html";
    }
}

document.addEventListener("DOMContentLoaded", function () {
    addSubjectStatusBadges();
    initLastLocationTracking();
    initContinueButton();
});
