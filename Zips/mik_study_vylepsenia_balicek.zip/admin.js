const STORAGE_KEY = "mikStudyAdminData";

function getData() {
    const saved = localStorage.getItem(STORAGE_KEY);

    if (!saved) {
        return {
            materials: [],
            questions: []
        };
    }

    try {
        return JSON.parse(saved);
    } catch (error) {
        return {
            materials: [],
            questions: []
        };
    }
}

function saveData(data) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data, null, 2));
}

function showExport() {
    const output = document.getElementById("adminOutput");
    output.textContent = JSON.stringify(getData(), null, 2);
}

document.getElementById("materialForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const data = getData();

    data.materials.push({
        subject: document.getElementById("materialSubject").value,
        title: document.getElementById("materialTitle").value,
        type: document.getElementById("materialType").value,
        description: document.getElementById("materialDescription").value,
        createdAt: new Date().toISOString()
    });

    saveData(data);
    this.reset();
    showExport();
});

document.getElementById("questionForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const data = getData();

    const rawAnswers = document.getElementById("questionAnswers").value
        .split("\n")
        .map(function (line) {
            return line.trim();
        })
        .filter(Boolean);

    const answers = rawAnswers.map(function (line) {
        const correct = line.startsWith("*");

        return {
            text: correct ? line.slice(1).trim() : line,
            correct: correct
        };
    });

    data.questions.push({
        subject: document.getElementById("questionSubject").value,
        text: document.getElementById("questionText").value,
        answers: answers,
        explanation: document.getElementById("questionExplanation").value,
        createdAt: new Date().toISOString()
    });

    saveData(data);
    this.reset();
    showExport();
});

document.getElementById("exportBtn").addEventListener("click", showExport);

document.getElementById("clearBtn").addEventListener("click", function () {
    const confirmed = confirm("Naozaj chceš vymazať lokálne admin dáta?");

    if (confirmed) {
        localStorage.removeItem(STORAGE_KEY);
        showExport();
    }
});

showExport();
