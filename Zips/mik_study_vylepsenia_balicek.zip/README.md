# MIK Study Hub – balík vylepšení

Tento ZIP obsahuje kódy na vylepšenie celej stránky.

## Súbory

- `index.html` – vylepšená hlavná stránka s Najnovšie pridané.
- `improvements.css` – jednotný farebný štýl cez `:root`, modrá farba, kvíz štýly, admin štýly.
- `subject-search.js` – vyhľadávanie v jednotlivých predmetoch.
- `quiz-enhanced-template.js` – vylepšený kvíz engine.
- `linux-quiz-section-example.html` – ukážka novej sekcie kvízu pre Linux.
- `admin.html` – jednoduchý lokálny admin panel.
- `admin.js` – logika admin panelu.
- `footer-snippet.html` – pätička s požadovaným textom.

## Ako zapojiť improvements.css

Do každého HTML súboru za `style.css` pridaj:

```html
<link rel="stylesheet" href="../improvements.css">
```

Na hlavnej stránke, kde je `index.html`, použi:

```html
<link rel="stylesheet" href="improvements.css">
```

## Ako pridať vyhľadávanie do predmetu

Do predmetovej stránky napríklad pod začiatok `.subject-main` vlož:

```html
<div id="subjectSearchMount"></div>
```

Pred `</body>` pridaj:

```html
<script src="../subject-search.js"></script>
```

## Ako použiť nový kvíz

Pozri súbor:

`linux-quiz-section-example.html`

Ten ukazuje, aké HTML ID musí mať sekcia kvízu.

## Admin panel

Súbory:

```text
admin.html
admin.js
```

daj do hlavného priečinka projektu vedľa `index.html`.

Admin panel zatiaľ ukladá dáta iba do `localStorage`.
Ďalší krok môže byť Firebase.
