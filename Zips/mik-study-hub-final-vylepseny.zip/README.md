# MIK Study Hub – finálna verzia s vylepšeniami

Táto verzia už obsahuje:

- jednotný dizajn cez `:root` v `style.css`,
- hlavná farba `#65d4f2`,
- mobilné menu,
- sekcia Najnovšie pridané,
- vyhľadávanie na hlavnej stránke,
- vyhľadávanie v každom predmete,
- progres učenia pre každý predmet,
- tlačidlá „Označiť ako naučené“,
- filtrovanie materiálov podľa typu: PDF, kvíz, zadanie, ťahák,
- kvízy v režime cvičenie / skúška / iba nesprávne otázky,
- výsledková obrazovka testu,
- admin panel cez localStorage,
- pätička s upozornením, že stránka je neoficiálna študentská pomôcka.

## Spustenie

Otvor `index.html` v prehliadači.

## Dôležité súbory

- `index.html` – hlavná stránka
- `style.css` – celý dizajn
- `script.js` – mobilné menu a vyhľadávanie predmetov
- `progress.js` – progres učenia
- `subject-search.js` – vyhľadávanie v predmete
- `filters.js` – filtrovanie materiálov
- `quiz-engine.js` – univerzálny kvíz engine
- `quiz-linux.js` – Linux otázky (151 otázok)
- `quiz-msd.js` – MSD otázky (20 otázok)
- `admin.html` a `admin.js` – lokálny admin panel
